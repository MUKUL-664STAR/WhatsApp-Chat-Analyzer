# WhatsApp Chat Analyzer - Docker Deployment

Complete full-stack application with Docker support for easy deployment.

## 🐳 Quick Start with Docker

### Prerequisites
- Docker (20.10+)
- Docker Compose (2.0+)

### Run Full Stack Application

```bash
# From project root
docker-compose up -d

# Access the application
Frontend: http://localhost:3000
Backend API: http://localhost:5000
```

### Stop Application

```bash
docker-compose down
```

## 📦 Individual Service Management

### Backend Only

```bash
# Build
cd backend
npm run docker:build

# Run
npm run docker:run

# Or with docker-compose
npm run docker:dev
```

### Frontend Only

```bash
# Build
cd frontend
npm run docker:build

# Run
npm run docker:run

# Or with docker-compose
npm run docker:dev
```

## 🛠️ Development

### Local Development (without Docker)

**Backend:**
```bash
cd backend
npm install
npm run build
npm run dev
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

### Docker Development with Hot Reload

```bash
# Run in development mode
docker-compose -f docker-compose.dev.yml up
```

## 📋 Available Scripts

### Backend Scripts

| Command | Description |
|---------|-------------|
| `npm start` | Start production server |
| `npm run dev` | Start development server with ts-node |
| `npm run dev:watch` | Start with nodemon auto-reload |
| `npm run build` | Build TypeScript to JavaScript |
| `npm run build:watch` | Build with watch mode |
| `npm run clean` | Remove dist folder |
| `npm run docker:build` | Build Docker image |
| `npm run docker:run` | Run Docker container |
| `npm run docker:dev` | Run with docker-compose (dev) |
| `npm run docker:prod` | Run with docker-compose (prod) |
| `npm run docker:stop` | Stop docker-compose |
| `npm run docker:logs` | View backend logs |

### Frontend Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start Vite dev server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |
| `npm run docker:build` | Build Docker image |
| `npm run docker:run` | Run Docker container |
| `npm run docker:dev` | Run with docker-compose (dev) |
| `npm run docker:prod` | Run with docker-compose (prod) |
| `npm run docker:stop` | Stop docker-compose |
| `npm run docker:logs` | View frontend logs |

## 🏗️ Project Structure

```
assignment/
├── backend/
│   ├── src/
│   │   ├── routes/
│   │   │   ├── index.ts          # Main router
│   │   │   └── chatRoutes.ts     # Chat endpoints
│   │   ├── controllers/          # Request handlers
│   │   ├── middleware/           # Express middleware
│   │   ├── validators/           # Joi validation
│   │   ├── services/             # Business logic
│   │   ├── utils/                # Helper functions
│   │   ├── models/               # Data models
│   │   └── index.ts              # Server entry point
│   ├── assets/                   # Static files
│   ├── Dockerfile                # Backend Docker config
│   ├── .dockerignore
│   ├── tsconfig.json             # TypeScript config
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/           # React components
│   │   ├── App.jsx               # Main app component
│   │   ├── main.jsx              # Entry point
│   │   └── index.css             # Tailwind styles
│   ├── Dockerfile                # Frontend Docker config
│   ├── nginx.conf                # Nginx configuration
│   ├── .dockerignore
│   └── package.json
├── docker-compose.yml            # Multi-container setup
└── README.md                     # This file
```

## 🔧 Backend Architecture (MVC + TypeScript)

### Routing Structure

The backend uses a centralized routing system:

**`src/index.ts`** → Main server file
  ↓
**`src/routes/index.ts`** → Central router
  ↓
**`src/routes/chatRoutes.ts`** → Chat-specific routes
  ↓
**`src/controllers/`** → Route handlers
  ↓
**`src/services/`** → Business logic

### Key Features

- ✅ **TypeScript** - Full type safety
- ✅ **MVC Architecture** - Organized code structure
- ✅ **Centralized Routing** - Clean route management
- ✅ **Joi Validation** - Request validation
- ✅ **Crypto-js** - Data encryption
- ✅ **Compression** - Response optimization
- ✅ **CORS** - Cross-origin support
- ✅ **Error Handling** - Standardized responses

## 🎨 Frontend Stack

- **React 18** - UI library
- **Tailwind CSS 3** - Utility-first styling
- **Vite** - Fast build tool
- **Chart.js** - Data visualization
- **Nginx** - Production web server

## 📊 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/analyze` | Analyze chat file |
| GET | `/api/statistics` | Get statistics |

## 🔐 Environment Variables

### Backend (.env)

```env
NODE_ENV=production
PORT=5000
CORS_ORIGIN=http://localhost:3000
```

### Frontend (.env)

```env
VITE_API_URL=http://localhost:5000
```

## 🚀 Production Deployment

### Build and Deploy

```bash
# Build images
docker-compose build

# Deploy with compose
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f

# Scale services
docker-compose up -d --scale backend=3

# Stop and remove
docker-compose down
```

### Docker Hub Deployment

```bash
# Tag images
docker tag whatsapp-analyzer-backend yourusername/whatsapp-backend:latest
docker tag whatsapp-analyzer-frontend yourusername/whatsapp-frontend:latest

# Push to Docker Hub
docker push yourusername/whatsapp-backend:latest
docker push yourusername/whatsapp-frontend:latest
```

## 📈 Health Checks

Both services include health checks:

- **Backend**: `GET /api/health` (every 30s)
- **Frontend**: `wget http://localhost:80/` (every 30s)

## 🔍 Troubleshooting

### Backend won't start

```bash
# Check logs
docker-compose logs backend

# Restart service
docker-compose restart backend
```

### Frontend can't connect to backend

1. Check CORS settings in backend
2. Verify network connectivity: `docker-compose exec frontend ping backend`
3. Check nginx proxy configuration

### Clear and rebuild

```bash
# Remove all containers and volumes
docker-compose down -v

# Rebuild from scratch
docker-compose build --no-cache

# Start fresh
docker-compose up -d
```

## 📝 Development Tips

1. **TypeScript Compilation**: Run `npm run build:watch` in backend for auto-compilation
2. **Hot Reload**: Frontend Vite dev server supports HMR out of the box
3. **Logs**: Use `docker-compose logs -f` to monitor both services
4. **Debug**: Attach to container: `docker exec -it whatsapp-analyzer-backend sh`

## 📄 License

MIT

## 👤 Author

Your Name

---

**Made with ❤️ using Docker, TypeScript, React, and Tailwind CSS**
